 -- create database shopping;
use shopping;
 -- create table Products(proid int primary key,prodname varchar(30), price int,quantity int);
insert into Products values(6,"ac",19000,1),
							(7,"led",50000,2),
                            (8,"watch",8000,4),
                            (9,"shoes",10000,3),
                            (10,"heels",2500,1);
select * from Products;


-- ascending
SELECT * from Products ORDER BY prodname ASC;
-- decending
SELECT * from Products ORDER BY prodname DESC;


SELECT proid FROM products WHERE proid BETWEEN 1 AND 6;

SELECT quantity FROM products WHERE quantity>2 AND quantity=3;
SELECT quantity,prodname FROM products WHERE quantity=1;



