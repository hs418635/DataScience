create database ecommarce;
use ecommarce;

create table shopping(proid int primary key,prodname varchar(30),price int);
insert into shopping values(7,"mobile",25000,1),
							(6,"laptop",40000,1),
							(8,"watch",2500,8),
                            (5,"headphone",3000,9);
 alter table shopping add quantity int;                           
select * from shopping;

-- count
select count(proid) from shopping;

-- average
select avg(price) from shopping;

-- min
select min(price) as smallerprice
from shopping;
-- max
select max(price) as maximumprice from shopping;

-- sum
select sum(price) from shopping;

-- case
select proid ,quantity, case
when quantity >3 then "the quantity is greater than 3"
when quantity <3 then "the quantity is less then 3"
else "the quantity is under 3"
end as prodname from shopping;



















