
-- it will add the next 20 days
select adddate('2023-04-01',interval 20 day);

-- addtime
select addtime ('10:40:32','06:04:01');

-- current date
select curdate();
-- current time
select current_time();

-- date-format
select date_format("2023-04-01", '%a %b %c');

-- day of month
select dayofmonth('2023-04-01');

-- date difference
select datediff('2023-04-01','2023-03-20')

-- date sub
select date_sub('2023-3-31',interval 30 day);

-- day name
select dayname('2023-04-01');

-- day of week
select dayofweek('2023-04-01');
-- day of year
select dayofyear('2023-04-01');

-- localtime
select localtime();
-- minute
select minute('12:38:48');
-- leap year 1st
select from_days(366)
-- current date and time
select now();
-- addition
select now()+12;
-- week
select week('2019-05-25');

-- year
select year('2023-04-01')


















































