create database mydb;
use mydb;
create table table1(name varchar(255),age int,salary int,address varchar(50));
show tables;
insert into table1 values("ram",12,12000,"indore"),
						("shyam",23,15000,"bhopal"),
                        ("raman",76,19000,"channai"),
						("krishna",89,170000,"banglore"),
                        ("krish",18,9000,"jaipur");
select * from table1;


create table table2(name varchar(255),age int,address varchar(50));
show tables;
insert into table2 values("ramesh",12,"india"),
						("ram",12,"indore"),
						("shyam",28,"pune"),
                        ("suresh",79,"rajasthan"),
						("nimi",69,"mumbai");
select * from table2;

#left join
select * from table1 as t1
left outer join table2 as t2
on t1.name=t2.name;

#right join
select * from table1 as t1
right outer join table2 as t2
on t1.name=t2.name

#inner join
select * from table1 as t1
inner join table2 as t2
on t1.name=t2.name

#full outer join
select * from table1 as t1
full join table2 as
on t1.name=t2.name 



#cross join
select * from table1 cross join table2


















