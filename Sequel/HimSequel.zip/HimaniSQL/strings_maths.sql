CREATE DATABASE mylivewire;
use mylivewire;
CREATE TABLE employee (emp_id INT, emp_name VARCHAR(255), 
                                  emp_city VARCHAR(255),
                                  emp_country VARCHAR(255),
                                  PRIMARY KEY (emp_id));
                                  

INSERT INTO employee VALUES (101, 'Utkarsh Tripathi', 'Varanasi', 'India'),
                            (102, 'Abhinav Singh', 'Varanasi', 'India'), 
                            (103, 'Utkarsh Raghuvanshi', 'Varanasi', 'India'),
                            (104, 'Utkarsh Singh', 'Allahabad', 'India'),
                            (105, 'Sudhanshu Yadav', 'Allahabad', 'India'),
                            (106, 'Ashutosh Kumar', 'Patna', 'India');
select * from employee;
-- Replace string in a table
SELECT REPLACE('Ashutosh','o','i');

SELECT emp_name,emp_country,
REPLACE(emp_country,'a','ana') 
FROM employee 
WHERE emp_country='india';



-- Select string in a single table
SELECT * FROM employee WHERE emp_name LIKE '%UT%';











-- case
SELECT CASE emp_name
WHEN 'Abhinav Singh' THEN 'Name is Abhi'
WHEN 'Utkarsh' THEN 'Name is Utkarsh'
ELSE ' You have selected other user'
END AS Result
FROM employee;

