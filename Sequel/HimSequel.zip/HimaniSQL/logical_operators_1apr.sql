show databases;
create database demo;
use demo;
create table employee(emp_id int, emp_name varchar(255),emp_city varchar(255),emp_country varchar(255),primary key(emp_id));
show tables;
insert into employee values(101,"john","banglore","india"),
							(102,"rohit","patna","india"),
							(103,"ram","banglore","india"),
                            (104,"rahul","channai","india"),
							(105,"ramesh","banglore","india"),
                            (106,"geeta","channai","india"),
							(107,"krishna","banglore","india");
select * from employee;

-- and -->it will gove only channai city
select * from employee where emp_city='channai' and emp_country='india';
-- in -->it will only give banglore and patna
select * from employee where emp_city in('banglore','patna');
-- not like --> except banglore it will give
 select * from employee where emp_city not like 'b%';
 -- or
 select * from employee where emp_city="banglore" or emp_country='india';
 
 -- between
 select * from employee where emp_id between 101 and 104;
-- All with subquery--> it  is written inside the main query with parenthesis()
select * from employee where emp_id=all
					(select emp_id from employee where emp_city="patna");
 
 -- exists
 select emp_name from employee where exists 
					(select emp_id from employee where emp_city="channai");
                    
 -- some
 select * from employee where emp_id > some
				(select emp_id from employee where emp_city="patna");
 
 
 
 
 
 
 
                    
                    
                    
                    

















