show databases;
#dropping a database
DROP DATABASE mydb;  
use mydata;
#adding a column to customer table
ALTER TABLE Customers  
ADD email varchar(40) NOT NULL; 
 
select * from Customers;
#Adding Multiple column

ALTER TABLE Customers 
ADD country varchar(100) NOT NULL  
AFTER name,  
ADD salary int(100) NOT NULL  
AFTER Age ;  

#rename the table name
RENAME table Customers TO Employee;  
select * from Employee;
ALTER TABLE Employee RENAME TO NewData;  
#show columns
show columns from NewData;
#Truncate table--> remove data
truncate table NewData;
select * from NewData;




