create database livewire
show databases
use livewire
create table demo(name varchar(30),age int,address varchar(50))
show tables
insert into demo values("ram",21,"bhopal")
insert into demo values("ramesh",87,"banglore")
insert into demo values("raman",29,"channai")
insert into demo values("shyam",28,"mumbai")
insert into demo values("krishna",22,"indore")


#adding a new column
alter table demo add email varchar(40) not null
#adding multiple columns
alter table demo add country varchar(50) not null
after name,
add salary int(10) not null after age
select * from demo
#renaming the table using alter
alter table demo rename to employee
select * from employee

#show columns
show columns from employee
#truncate table --to remove the data without changing structure

truncate table employee
select * from employee
#check it 

select age,name from demo where address='bhopal';











