CREATE DATABASE mydb;
USE MYDB;

CREATE TABLE USER
(
 id int unsigned NOT NULL auto_increment,
 username varchar(100) NOT NULL,
 email varchar(100) NOT NULL,
 PRIMARY KEY (id)
);

SHOW TABLES;

INSERT INTO user( username, email )
VALUES ( "HIMANI", "him@example.com" );

select * from user;
#updating the id
UPDATE user SET username="Ankita" WHERE id=1



