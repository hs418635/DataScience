
 show databases;
 use shopping;
 show tables;
 select * from products;
 select replace('laptop','top','pi');  # old value , new value
 
 use mydatabase;
 select * from employee;
 
 select emp_name,emp_country,
 replace(emp_country,'a','ana')
 from employee
 where emp_country='india';
 
 -- select string in a single table
 select * from employee where emp_name like'%ut%';
 
 -- without table
 
 
 select ascii('2');
 select bin(12);
 select bit_length('text');
 select length(@hello),char_length(@hello);
 select concat('live','wi','re');
 select field('Bb','Aa',23456789,00011111);
 select find_in_set('b','a,b,c,d');
 select insert('livewire',3,4,'indore');# 3rd index and 4 character
 select locate('wear','footwear');
 select lower('LIVEWIRE');
 select repeat('live',3);
 select reverse('livewire');
 select right('livewire',4);
 select substring('livewire' from 4);
 select upper('livewirwe');
 -- math
 select pi();
 select pow(2,3);
 select 4%3;
 select abs(-3);
 select ceiling(1.23);#it will provide the next value 
 select exp(5);
 select floor(1.45);# it will give the previous value
 select log(2);
 select mod(234,10);
 select sqrt(81);
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

 
 
 
 
 
 