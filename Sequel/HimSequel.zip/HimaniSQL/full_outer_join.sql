use livewire
create table customers(cust_id int ,cust_name varchar(250),cust_city varchar(200),primary key (cust_id))
insert into customers values(1,"ram","indore"),
							(2,"rahesh","bhopal"),
                            (3,"rahul","channai"),
                            (4,"raman","mumbai");
create table customer2(s_id int ,s_name varchar(250),s_city varchar(200),primary key (s_id));
insert into customer2 values(1,"ram","indore"),
							(2,"rahesh","bhopal"),
                            (3,"rahul","channai"),
                            (4,"raman","mumbai");
select * from customer2;
update customers set cust_name='krishna' where cust_id=3;
update customers set cust_city='indore' where cust_id=4

delete from customers where cust_id=2


#if ful outer jpoin is not working alternate way
SELECT * FROM customers
       LEFT JOIN customer2 ON cust_id= s_id
       UNION
       SELECT * FROM customers
       RIGHT JOIN customer2 ON cust_id = s_id;