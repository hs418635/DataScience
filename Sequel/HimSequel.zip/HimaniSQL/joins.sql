use mydata;

create table Table1(name varchar(20),age int,address varchar(30));
insert into Table1 values("ram",12,"indore");
insert into Table1 values("shyam",19,"bhopal");
insert into Table1 values("ramesh",20,"banglore");
insert into Table1 values("raju",18,"channai");
insert into Table1 values("suresh",21,"mumabai");
insert into Table1 values("shreya",11,"america");
select * from Table1;

create table Table2(name varchar(20),age int,address varchar(30),salary int);
insert into Table2 values("ram",12,"indore",10000);
insert into Table2 values("sohan",19,"bhopal",20000);
insert into Table2 values("ramesh",20,"banglore",30000);
insert into Table2 values("rajeshwari",18,"tamilandu",69000);
insert into Table2 values("surbhi",21,"rajasthan",76890);
insert into Table2 values("shreya",19,"panjab",87900);
select * from Table2;


#Left outer join
SELECT * FROM Table1 as t1 
LEFT OUTER JOIN Table2 as t2
on t1.name=t2.name

#Right outer join
SELECT * FROM Table1 as t1 
RIGHT OUTER JOIN Table2 as t2
on t1.name=t2.name

#Full outer join
SELECT * FROM Table1 as t1 
FULL outer JOIN Table2 as t2
on t1.name=t2.name

# Inner join
SELECT * FROM Table1 as t1 
INNER JOIN Table2 as t2
on t1.name=t2.name

# Cross join
SELECT * FROM Table1
CROSS JOIN Table2