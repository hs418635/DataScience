create database livewire;
use livewire;

CREATE TABLE CAR (
			MPG integer NOT NULL,
            CYL DECIMAL(10 , 2 ) NULL,
			ENG DECIMAL(10 , 2 ) NULL,
            WT DECIMAL(10 , 2 ) NULL,
            VS VARCHAR(255)
            
);
-- got o schema there find tablename you have created then right click over the table and find the import wizard option and emport delimeter csv file
SELECT * FROM livewire.car;
select MPG,VS from car where VS='Y';