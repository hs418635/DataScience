create database merge;
use merge;
create table  authors(id int not null auto_increment,name varchar(40) not null,country varchar(50),primary key(id));
show tables;
insert into authors(name,country) values("villiam","usa"),
										("john","uk"),
                                        ("reeta","frace");
select * from authors;

-- table 2
create table books (id int not null auto_increment ,title varchar(50) not null,primary key(id));
insert into books(id,title)values(1,"the wings of fire"),
								(2,"the autobiography"),
								(3,"mier kamlf");

select * from books;
-- table3
create table booksauthors(authorid int not null,bookid int not null,foreign key(authorid) references authors(id),
foreign key(bookid) references books(id));

insert into booksauthors(bookid,authorid) values(1,3),
												(2,1),
												(3,2);

select ba.authorid,
a.name authorname,
ba.bookid,
b.title booktitle
from booksauthors ba inner join authors a on a.id=ba.authorid
inner join books b on b.id=ba.bookid


