use mydatabase;
show tables;
select * from employee;
insert into employee values(107,'seena','bhopal','india');
-- subquery
select * from employee where emp_name in (select emp_name from employee) ;

-- limit
select * from employee limit 3;

-- count --group by
select count(emp_id) ,emp_country from employee group by emp_country;

-- having clause
select count(emp_id) ,emp_country from employee group by emp_country having 
count(emp_id) >= 7;




