create database shopping;
use shopping;
create table Products(proid int primary key,prodname varchar(30), price int,quantity int);
insert into Products values(1,"mobile",15000,1),
							(2,"laptop",50000,2),
                            (3,"smartwatch",8000,4),
                            (4,"earbuds",10000,3),
                            (5,"neckband",2500,1);
select * from Products;


SELECT COUNT(proid)
FROM Products;

SELECT AVG(price)
FROM Products;
-- min
SELECT MIN(Price) AS SmallestPrice
FROM Products;
-- max
SELECT MAX(Price) AS LargestPrice
FROM Products;
-- sum
SELECT SUM(Quantity)
FROM Products;
-- case


SELECT proid, Quantity,
CASE
    WHEN Quantity > 3 THEN 'The quantity is greater than 3'
    WHEN Quantity = 3 THEN 'The quantity is 3'
    ELSE 'The quantity is under 3'
END AS prodname
FROM Products;
