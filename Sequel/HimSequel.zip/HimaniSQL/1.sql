create database mydata;
use mydata;

create table customers(name char(20),age int(3),address char(50),phone char(10));

insert into customers values("ankita",3,"indore","123456745");
insert into customers values("ankit",4,"india","12956745");
insert into customers values("ariana",3,"enland","12994745");
insert into customers values("himanshu",3,"bhopal","12006745");
insert into customers values("nimi",3,"bangladesh","123400045");

select * from customers;
select name,age,address from customers;